import { MyserviceService } from './myservice.service';
import { MessageService } from './appServices/message';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppyComponent } from './app.component';
import { AyaComponent } from './aya/aya.component';
import { Aya1Component } from './aya1/aya1.component';
import { HighlightDirective } from './highlight.directive';
import { UnlessDirective } from './unless.directive';
import { MultiplierPipe } from './multiplier.pipe';
import { IsdInrPipe } from './multiplier/isd-inr.pipe';
import { ExponentPipe } from './multiplier/exponent.pipe';
import { FactorialPipe } from './multiplier/factorial.pipe';
import { FibonacciPipe } from './multiplier/fibonacci.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {MatChipsModule} from '@angular/material/chips';
import {MatIconModule} from '@angular/material/icon';
import {MatRadioModule} from '@angular/material/radio';
import {MatInputModule} from '@angular/material/input';
import { HttpClientModule } from '@angular/common/http';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatTableModule} from '@angular/material/table';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { ServicecomponentComponent } from './servicecomponent/servicecomponent.component';






@NgModule({
  declarations: [
    AppyComponent,
    AyaComponent,
    Aya1Component,
    HighlightDirective,
    UnlessDirective,
    MultiplierPipe,
    IsdInrPipe,
    ExponentPipe,
    FactorialPipe,
    FibonacciPipe,
    ServicecomponentComponent,



  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
     MatButtonModule,
     MatCardModule,
     MatChipsModule,
     MatButtonModule,
     MatIconModule,
     MatRadioModule,
     MatInputModule,
     HttpClientModule,
     MatPaginatorModule,
     MatTableModule,
     MatProgressSpinnerModule

  ],
  providers: [MessageService,MyserviceService
],
  bootstrap: [AppyComponent]
})
export class AppModule { }
