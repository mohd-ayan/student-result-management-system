import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-servicecomponent',
  templateUrl: './servicecomponent.component.html',
  styleUrls: ['./servicecomponent.component.css']
})
export class ServicecomponentComponent implements OnInit {

  constructor(private user:UserserviceService)
  {
    this.user.showdata().subscribe((data :any)=>
    {
      console.log(data);
      this.universitydata=data;
    })
  }

  ngOnInit(): void {
  }

  universitydata:Array<{
    alpha_two_code:string,
    country:string,
    domains:string,
    name:string,
    state_province:string,
    web_pages:string
  }>=[]



}
