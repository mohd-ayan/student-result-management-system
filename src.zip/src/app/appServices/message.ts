export class MessageService
{
  message()
{
  alert("thanks for click");
}


checkmessage(a:any)
{

  alert(a);

}


}

