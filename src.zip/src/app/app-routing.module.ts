import { AppyComponent } from './app.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutComponent } from './about/about.component';
import { Aya1Component } from './aya1/aya1.component';
import { AyaComponent } from './aya/aya.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  // {path:'first', component:AyaComponent},
  // {path:'second',component:Aya1Component},
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'about',component:AboutComponent},
  {path:'contactus',component:ContactusComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


// const routes: Routes = [
//   { path:'abc', component: AyaComponent},
//   { path: 'def', component: Aya1Component}
// const routes :Routes=[{path:'firstrouter' , component : Ayacomponent}
// path:'secondrouter', component ; Aya1component]
// ];
