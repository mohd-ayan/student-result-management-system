import { FormBuilder } from '@angular/forms';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor() { }

  users:Array<{
    name:string
    id:number
  }>=[
    {name:'ayan',id:1},
    {name:'mohd',id:2},
    {name:'mohammad',id:3}
  ]
  newform()
  {


  }

}
