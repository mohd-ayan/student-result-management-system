import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { MessageService } from '../appServices/message';

@Component({
  selector: 'app-aya1',
  templateUrl: './aya1.component.html',
  styleUrls: ['./aya1.component.css']
})
export class Aya1Component implements OnInit {

// @Input() aya1="tea"

@Input() giveinput=''

giveout='this is child'

@Output() output:EventEmitter<any>= new EventEmitter();

// send()
// {
//   let json={
//       name:'abcd',
//       msg:this.giveout
//     }
//     this.output.emit(json)
//   this.output.emit(this.giveout);
// }




// check()
// {
//   const mgsservices=new MessageService()
//   mgsservices.message();
// }

  constructor() { }

  // @Input() takeinput:string=''
  // @Output() output:EventEmitter<any> = new EventEmitter();
  // outputstring='hello this is a child component'

  ngOnInit(): void
  {
    // console.log(this.takeinput);

    // console.log(this.giveinput)
  }

  //senddata(){
    // let json={
    //   name:'abcd',
    //   msg:this.outputstring
    // }
    // this.output.emit(json)
  //   this.output.emit(this.outputstring)
  // }



  // send(){
  //   this.click+=1
  //   this.out.emit('Clicked :' + this.click)
  // }

  // first=0;
  // second=1
  // sum=0;
  // i=0;
  // printfib()
  // {
  //   if(this.i<=7)
  //   {
  //     this.output.emit('sum is  :' +this.sum);
  //     this.sum=this.first+this.second
  //     this.first=this.second
  //     this.second=this.sum
  //     this.i++;
  //     this.printfib()
  //   }
  // }




}
