import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Aya1Component } from './aya1.component';

describe('Aya1Component', () => {
  let component: Aya1Component;
  let fixture: ComponentFixture<Aya1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Aya1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Aya1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
