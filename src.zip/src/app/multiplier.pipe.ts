import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'multiplier'
})
export class MultiplierPipe implements PipeTransform {

  transform(value: number, multiply: string): number {
    let mul=parseFloat(multiply);
    console.log(this.arr)
    console.log(...this.arr)
    return mul*value;
  }
arr=[0,1,2,3]



}
