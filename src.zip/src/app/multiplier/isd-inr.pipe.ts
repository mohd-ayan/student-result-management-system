import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'isdInr'
})
export class IsdInrPipe implements PipeTransform {

  transform(value: number,...args:any): unknown{
    let price=args[0];
    // console.log(this.arr)
    // console.log(...this.arr)

    //console.log(value,price,args,value*price)
    return value*price;
  }


arr=[0,1,2,3]



}
