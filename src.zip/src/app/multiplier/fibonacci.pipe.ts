import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fibonacci'
})
export class FibonacciPipe implements PipeTransform {

  transform(value: number, fib:number[]): number {

    let first=0,second=1,fibo;
    for(let i=1;i<=7;i++)
    {
      fibo=first+second;
      first=second;
      second=fibo;
    }
    return first;
  }

}
