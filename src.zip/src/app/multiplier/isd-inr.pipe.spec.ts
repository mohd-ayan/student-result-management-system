import { IsdInrPipe } from './isd-inr.pipe';

describe('IsdInrPipe', () => {
  it('create an instance', () => {
    const pipe = new IsdInrPipe();
    expect(pipe).toBeTruthy();
  });
});
