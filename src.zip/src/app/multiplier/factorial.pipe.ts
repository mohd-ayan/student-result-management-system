import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'factorial'
})
export class FactorialPipe implements PipeTransform {

  transform(value: number, fact= 1): number {
    for(let i=1;i<=5;i++)
    {
      fact=fact*i;
    }
    return fact;
  }

}
