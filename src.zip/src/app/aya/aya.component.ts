import { Component, OnInit } from '@angular/core';
import { MessageService } from '../appServices/message';
@Component({
  selector: 'app-aya',
  templateUrl: './aya.component.html',
  styleUrls: ['./aya.component.css']
})
export class AyaComponent implements OnInit
 {

  constructor(private mm:MessageService) { }

  fanme:string=''
  age:number=0;
  male:string=''
  female:string=''
  dob:number=0;


  ngOnInit(): void
  {
  }

  btnclick()
  {
    // const msgservices = new MessageService();
    // msgservices.message();
    this.mm.message()

  }

  clickbtn()
  {
    this.mm.checkmessage('ayan');
  }






}
