import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  constructor(private http:HttpClient, private hptt: HttpClient) {}
  url ="https://agrodev.pristinefulfil.com/api/User/CreateUser"
getdata()
  {
     let url="https://agrodev.pristinefulfil.com/api/Item/GStSetupGet"
     return this.http.get(url);
  }

  url1 = "http://universities.hipolabs.com/search?country=United+States"
  showdata()
  {
    let url1 = "http://universities.hipolabs.com/search?country=United+States"
    return this.hptt.get(url1);
  }
}
