import { MatTableDataSource } from '@angular/material/table';
import { UserserviceService } from './userservice.service';

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { EmailValidator, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService } from './appServices/message';
// import { MatInputModule } from "@angular/material/input";
// import {MatCardModule} from '@angular/material/card';
// import {COMMA, ENTER} from '@angular/cdk/keycodes';
// import {MatChipInputEvent} from '@angular/material/chips';
import { MatPaginator } from '@angular/material/paginator';


@Component({
  selector: 'mohd_ayan',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppyComponent implements OnInit {


  // presentdate=Date;
// inputstring='this is parent component..'


// m:any =''
// receive(x:any){
//   this.m=x
//   console.log(x)

name:string=''
course:string=''
year:any=''


studet:Array<{
name:string,
course:string,
year:number}>
=[{name:'ayan',course:'b-tech',year:1},
{name:'shahrukh',course:'b-tech',year:2},
{name:'ram',course:'mca',year:3},
{name:'kapil',course:'bca',year:4},
{name:'anil',course:'msc',year:2}]


addstudet()
{
  this.studet.push({name:this.name,course:this.course,year:this.year})
  this.name=''
  this.course=''
  this.year=''
}

deletestudet()
{
  this.studet.pop()
}

i:any
deleterow(i:any)
{
  this.studet.splice(i,1)
}

delselrow(i:number)
{

  this.studet.splice(i,1);
}

selectrow()
{
  const selectedrow = this.studet
}

//checkfillgroup//

checkfillgroup:FormGroup=this.fb.group({
  name:['',[Validators.required]],
  course:['',[Validators.required]],
  year:['',[Validators.required]]
})

checkfillgrouparray:Array<{
  name:string
  course:string
  year:number
}>=[{name:'mohit',course:'bba',year:1},
{name:'hritik',course:'bca',year:2},
{name:'akshay',course:'bcom',year:2},
{name:'akash',course:'b tech',year:4}]

addfillgroup()
{
  let json ={
    name:this.checkfillgroup.get('name')?.value,
    course:this.checkfillgroup.get('course')?.value,
    year : this.checkfillgroup.get('year')?.value
  }

  this.checkfillgrouparray.push(json);
}


//formgroup//
secondformgrp :FormGroup=this.fb.group({
  name:['',[Validators.required]],
  email:['',[Validators.required]],
  mobile:['',[Validators.required]],
  place:['',[Validators.required]]
})




num1:number=0
num2:number=0
num3:number=0
  userListMatTabDataSource: any;
add(num1:number,num2:number)
{
  this.num3=this.num1+this.num2
}

mydata:Array<{
  condition:string,
  effective_date:number,
  gst_component_code:string,
  gst_group_id:number,
  gst_jurisdiction_type:string,
  gst_state_code:string,
  gst_state_name:string,
  name:string,
  nav_seq_no:number,
  percentage:number,
  updated_on:number
}>=[]


ngOnInit(): void
{

};

agrodata:any=[]

constructor(private fb: FormBuilder, private ms:MessageService,private user:UserserviceService,private user1:UserserviceService)
{
  this.user.getdata().subscribe((data : any)=>{
    console.log(data)
    this.dataSource = new MatTableDataSource<any>(data);
    this.dataSource.paginator = this.paginator;



  })

}

enter1:string=''
dataSource : MatTableDataSource<any> = new MatTableDataSource<Array<any>>([]);
@ViewChild(MatPaginator) paginator!: MatPaginator ;
displayedColumns: string[] =['condition' , 'effective_date', 'gst_component_code' , 'gst_group_id' , 'gst_jurisdiction_type'
, 'gst_state_code','gst_state_name', 'name', 'nav_seq_no' , 'percentage', 'updated_on', 'enter1'];


  applyFilter(event: Event)
  {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toUpperCase();
  }










signup= new FormGroup({
  firstname: new FormControl("",[Validators.required]),
  lastname : new FormControl("",[Validators.required]),
  emailid : new FormControl("",Validators.required),
    address: new FormControl("",Validators.required),
    city : new FormControl("",Validators.required),
    state : new FormControl("",Validators.required),

})

get firstname(){
  return this.signup.get('firstname')

}







biosection = new FormGroup({
  firstname: new FormControl(),
   lastname: new FormControl(),
   age : new FormControl() });


callingfunction()
{
  console.log(this.biosection.value)

}
// firstname:any=''
// lastname:any=''
// emailid:any=''
// address:any=''
// city:any=''
// state:any=''

reactiveform= new FormGroup({
  firstname: new FormControl("",[Validators.required]),
  lastname : new FormControl("",[Validators.required]),
  emailid : new FormControl("",Validators.required),
    address: new FormControl("",Validators.required),
    city : new FormControl("",Validators.required),
    state : new FormControl("",Validators.required),

})

reactivearray:Array<{
  firstname:string,
  lastname:string,
  emailid:string,
  address:string,
  city:string,
  state:string
}>=[{firstname:'FjytDSF',lastname:'af',emailid:'mALE@gmail.com',address:'sre',city:'sre',state:'up'},
    {firstname:'FDdfdfSF',lastname:'ag',emailid:'mALE@gmail.com',address:'sre',city:'sre',state:'up'},
    {firstname:'FdfdDSF',lastname:'gr',emailid:'mALE@gmail.com',address:'sre',city:'sre',state:'up'},
    {firstname:'FDsdSF',lastname:'rr',emailid:'mALE@gmail.com',address:'sre',city:'sre',state:'up'},
    {firstname:'FDSF',lastname:'vsr',emailid:'mALE@gmail.com',address:'sre',city:'sre',state:'up'},
  ]

adddata()
{


  let json ={
    firstname:this.reactiveform.get('firstname')?.value,
  lastname:this.reactiveform.get('lastname')?.value,
  emailid:this.reactiveform.get('emailid')?.value,
  address:this.reactiveform.get('address')?.value,
  city:this.reactiveform.get('city')?.value,
  state:this.reactiveform.get('state')?.value
  }
    this.reactivearray.push(json)

    // console.log(firstname=this.firstname,this.lastname=this.lastname,this.emailid=this.emailid,
    //   this.address=this.address,this.city=this.city,this.state=this.state)
}

// ngsubmit()
// {
//   console.log(this.reactiveform.value )
// }














users:Array<{
  name:string
  id:number
  place:string
}>=[
  {name:'ayan',id:12,place:'sre'},
  {name:'mohd',id:11,place:'up'},
  {name:'mohammad',id:33,place:'uk'}
]

servicesform:FormGroup=this.fb.group({
  name:['',[Validators.required]],
  id:[0,[Validators.required]],
  place:['',[Validators.required]]

})

servicedata()
{
  let json=
  {
    name:this.servicesform.get('name')?.value,
    id:this.servicesform.get('id')?.value,
    place:this.servicesform.get('place')?.value
  }
  console.log(json)
  this.users.push(json);

}


// getuserformdata(data:any)
// {
//   // console.log(data)
//   this.user.saveuser(data).subscribe((result)=>
//   {
//     console.log(result);
//   })
// }

//Calculator///

subText='';
mainText='';
operand1=0;
operand2=0;
operator='';
calculationString='';
answered=false;
operatorSet=false;


presskey(key:string)
{
  if(key === '/' || key === '*' || key === '-' || key === '+')
  {
    const lastkey = this.mainText[this.mainText.length-1];
    if(lastkey === '/' || lastkey === '*' || lastkey === '-' || lastkey === '+')
    {
      this.operatorSet=true;
    }
    if((this.operatorSet) || (this.mainText === ''))
    {
      return;
    }
    this.operand1=parseFloat(this.mainText);
    this.operator=key;
    this.operatorSet=true;
  }
  if(this.mainText.length===10)
  {
    return;
  }
  this.mainText +=key;
}

getAnswer()
{
  this.calculationString=this.mainText;
  this.operand2=parseFloat(this.mainText.split(this.operator)[1]);
  if(this.operator === '/')
  {
    this.subText = this.mainText;
    this.mainText = (this.operand1 / this.operand2).toString();
    this.subText = this.calculationString;
    if(this.mainText.length>9)
    {
      this.mainText = this.mainText.substring(0,9);
    }
  }
  else if(this.operator === '*')
  {
    this.subText = this.mainText;
    this.mainText = (this.operand1 * this.operand2).toString();
    this.subText = this.calculationString;
    if(this.mainText.length>9)
    {
      this.mainText = 'Error';
      this.subText = 'Range Exceeded';
    }
  }
  else if(this.operator === '-')
  {
    this.subText = this.mainText;
    this.mainText = (this.operand1 - this.operand2).toString();
    this.subText = this.calculationString;
  }
  else if(this.operator === '+')
  {
    this.subText = this.mainText;
    this.mainText = (this.operand1 + this.operand2).toString();
    this.subText = this.calculationString;
  }
  if(this.mainText.length > 9)
  {
    this.mainText = 'Error';
    this.subText = 'Range Exceeded';
  }
  else
  {
    this.subText = 'Error:invalid Operation';
  }
  this.answered = true;

}

allClear()
{
  this.mainText=''
  this.subText=''
}






//name:string=''
  num:number=0
  email:string=''
checkvalidation:FormGroup = this.fb.group({

  name:['',[Validators.required,Validators.minLength(5)]],
  num:[0,[Validators.required,Validators.maxLength(10),Validators.minLength(10)]],
  email:['',[Validators.required,Validators.email]]
})

checkvalidationarray:Array<
{
  name:string,
  num:number,
  email:string,
}>=[]

dataadd()
{
  let json={
    name:this.checkvalidation.get('name')?.value,
    num:this.checkvalidation.get('num')?.value,
    email:this.checkvalidation.get('email')?.value
  }
  console.log(json)
  this.checkvalidationarray.push(json);

}




checkfields()
{
    alert("thanks for click");
}


formgrp:FormGroup=this.fb.group({
  name:['',[Validators.required]],
  number:['',[Validators.required]],
  email:['',[Validators.required]],
  course:['',[Validators.required]],
  branch:['',{}]
})




//FormGroup//

checkformgroup:FormGroup=this.fb.group({
  firstname:['',[Validators.required]],
  lastname:['',[Validators.required]],
  email:['',[Validators.required]],
  phone_no:['',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
  course:['',[Validators.required]],
  branch:['',[Validators.required]]
})


checkformarray:Array<{
  firstname:string
  lastname:string
  email:string
  phone_no:number
  course:string
  branch:string

}>=[{firstname:'mohd',lastname:'ayan',email:'ayan@gmail.com',phone_no:9759220090,course:'b tech',branch:'cse'},
{firstname:'mohd',lastname:'shahrukh',email:'shahrukh@gmail.com',phone_no:7017463940,course:'b tech',branch:'cse'},
{firstname:'mohd',lastname:'zaid',email:'zaid@gmail.com',phone_no:7867459846,course:'b tech',branch:'cse'},
{firstname:'mohd',lastname:'haider',email:'haider@gmail.com',phone_no:9067897686,course:'b tech',branch:'cse'},
{firstname:'mohd',lastname:'altamash',email:'altamash@gmail.com',phone_no:701777313,course:'b tech',branch:'cse'},]

adddetails()
{
  let json={
  firstname:this.checkformgroup.get('firstname')?.value,
  lastname:this.checkformgroup.get('lastname')?.value,
  email:this.checkformgroup.get('email')?.value,
  phone_no:this.checkformgroup.get('phone_no')?.value,
  course:this.checkformgroup.get('course')?.value,
  branch:this.checkformgroup.get('branch')?.value
  }

  this.checkformarray.push(json);

}




// fieldform()
// {
//   let json=
//   {
//     firstname:this.checkformgroup.get('firstname')?.value,
//     lastname:this.checkformgroup.get('lastname')?.value,
//     email:this.checkformgroup.get('email')?.value,
//     phone:this.checkformgroup.get('phone')?.value,
//     course:this.checkformgroup.get('course')?.value,
//     branch:this.checkformgroup.get('branch')?.value,
//     address:this.checkformgroup.get('address')?.value,
//     city:this.checkformgroup.get('city')?.value,
//     state:this.checkformgroup.get('state')?.value,
//     College:this.checkformgroup.get('college')?.value,
//     Marks12:this.checkformgroup.get('marks12')?.value,
//     marks10:this.checkformgroup.get('marks10')?.value,
//     graduation:this.checkformgroup.get('graduation')?.value,
//     postgraduation:this.checkformgroup.get('postgraduation')?.value


//   }

//   this.checkformarray.push(json);

// }





fname= new FormControl('',[Validators.required, Validators.email])
received(x:any)
{
  console.log(x);
}


// email= new FormControl('',[Validators.email])
// check(){
//   console.log("Valid: "+this.fname.valid)
//   console.log('Invalid: '+this.fname.invalid)
//   console.log('Dirty: '+this.fname.dirty)
//   console.log('Pristine: '+this.fname.pristine)
//   console.log('Value: '+this.fname.value)
//   console.log(this.fname.errors)
//   console.log('validators: '+this.fname.validator)
//   console.log(this.fname)
// }
// checkForm(){
//   console.log("Valid: "+this.formGroupVAr.valid)
//   console.log('Invalid: '+this.formGroupVAr.invalid)
//   console.log('Dirty: '+this.formGroupVAr.dirty)
//   console.log('Pristine: '+this.formGroupVAr.pristine)
//   console.log(this.formGroupVAr.value)
//   console.log(this.formGroupVAr.errors)
//   console.log('validators: '+this.formGroupVAr.validator)
//   console.log(this.formGroupVAr.get('name')?.value)
//   console.log(this.formGroupVAr)
//   console.log(this.formGroupVAr.patchValue)
// }


price: number =0

price2: number =1

inputstring='this is parent...'

todaydate=new Date();




color = '';


  @Input() xyz =''

   }



//   @ViewChild('reff') yum: ElementRef
//   @ViewChild('ref') hh:ElementRef
  // @ViewChild('ref1') aa:ElementRef

//   addrow:Array<
//    {
//     fname:string,
//     age:number,
//     emailid:string,
//     dob:string
//   }>=[
//     {fname:'FjytDSF',age:34,emailid:'mALE',dob:'01/04/2021'},
//     {fname:'FDdfdfSF',age:34,gender:'mALE',dob:'01/04/2021'},
//     {fname:'FdfdDSF',age:34,gender:'mALE',dob:'01/04/2021'},
//     {fname:'FDsdSF',age:34,gender:'mALE',dob:'01/04/2021'},
//     {fname:'FDSF',age:34,gender:'mALE',dob:'01/04/2021'},
//   ]
//   fname:any=''
//   age:any=''
//   gender:any=''
//   dob:any=''

//   insertdata()
//   {
//     this.addrow.push({fname:this.fname, age:this.age,gender:this.gender,dob:this.dob})
//     console.log(this.fname,this.age,this.gender,this.dob)
//   // this.addrow(this.fname= this.fname , this.age= this.age );
//    this.fname=''
//    this.age=''
//    this.gender=''
//    this.dob=''
//   }

//   cons(){
//     this.yum.nativeElement.style.color='green'
//     console.log(this.yum.nativeElement.style.color)
//   }

//   changecolor()
//   {
//     this.hh.nativeElement.style.color='purple'
//   }

//   content()
//   {
//     this.aa.nativeElement.style.color='blue'
//   }

//   hide(a:any)
//   {
//     a.hidden=true
//   }
//   show(b:any)
//   {
//     b.hidden=false
//   }

//   delete()
//   {
//     this.addrow.pop()
//   }

// deleterow(index:any)
// {
//   console.log(index)
//   this.addrow.splice(index,1);
// }

// editrow(index:any)
// {
//   console.log(index)
//   this.fname=this.fname(index)

// }

// first:number=0
// second:number=1;
// fib:number=0
// i:number=0
// title = 'hello ayan'
// title1 = 'HELLO AYAN'
// // fibarr:Array<
// // {
// //   first:number
// // }> =[]

// withoutloop()
// {
//   if(this.i<=7)
//   {
//     console.log(this.first);
//     this.fib=this.first+this.second
//     this.first=this.second
//     this.second=this.fib;
//     this.i++;
//     this.withoutloop()
//   }

// }











  // deleteMsg(msg:string) {
    // const index: number = this.data.indexOf(msg);
    // if (index !== -1) {
        // this.data.splice(index, 1);
    // }
// }





  // i:any
  // index:any
  // deleterow(i:string)
  // {
    // const index :number=this.addrow.indexOf(this.i);
    // if(index!=-1)
    // {
      // this.addrow.splice(index,this.i);
    // }
      // this.addrow.splice(this.i);
  // }
  // presentDate = new Date();




  // con:Array<number>=[5,6,7,8,]
  // index =2;

  // column:Array<
  // {
  //   id:number
  //   address:string
  //   mobileNumber:number
  // }> =[]

  // id:any=''
  // address:string=''
  // mobileNumber:any=''

  // addcolumn()
  // {
  //   this.column.push({id:this.id,address:this.address,mobileNumber:this.mobileNumber})
  // }


//   name:Array<string> =[]
//   text=''
//   empty=''
//   num:any=''
//   rev:any=0;
//   rem:any=''

//   pushed()
//   {
//     this.name.push(this.text);
//     console.log(this.text)
//     this.text=''
//   }


//   reverse()
//   {
//     let temp=this.num
//     let res: string=''
//     this.rem= 0;
//     this.rev=0
//     while(temp>0)
//     {
//       this.rem=temp%10;
//       this.rev=(this.rev*10)+this.rem;
//       res+=this.rem
//       temp=Number(Math.floor(temp/10));
//       // if(this.rev.toString()?.length==this.num?.toString()?.length){
//       //   break
//       // }
//     }
//     console.log(res)
//     console.log(this.rev)
//   }


//   presentDate = new Date();

// num1:any=''

// check()
// {
//   if(this.num%2==0)
//   {
//     console.log("Even Number");
//   }
//   else
//   console.log("Odd Number");
// }



  // interface jsomType{
  //   name ?: string;
  //   age?: number;
  //   mobile?: number;
  //   email?: string;
  // }










//   num_1:Array<string> =['number','text','date','email','tel','submit','color','password']
//   num_2:Array<string> = ['number','text','date','email','tel','submit']
//   Name:Array<string> =['Name', 'Address', 'Email','Password']
//   Details:Array<string> = ['Phone', 'telephone','color','Password','submit']
//   student_details: {name : string, age: number, mobile: number, email: string} | string|number=1
//   button:Array<string> =['Ayan']

//   form : Array<jsomType> =[{name:'sd',age:32}]

  //   Student_Details:Array<
  //   {
  //     name:string,
  //     mobile:number,
  //     age:number;
  //     email:string
  //   }
  // > =[]


//   text:any=''
//   ty='text'
//   name=''
//   t='text'
//   tt='text'
//   ttt='text'
//   namme:any=''
//     // pushed()
//     // {
//     //  // this.Name.push('Phone_No');
//     //  //console.log(this.Name)
//     //  this.Name.push(...this.Name)
//     //  //console.log(this.Name)
//     // }

//     pushed()
//     {
//      // this.Name.push('Phone_No');
//      //console.log(this.Name)
//      this.Name.push(...this.namme)
//      //console.log(this.Name)
//     }

//     fname:string="Ayan";
//     greet()
//     {
//       alert("hello !!!" +this.fname);
//     }

//     lname:string="Gour";
//     check()
//     {
//       alert("hello" +this.lname);
//     }


//     // MakeButton(add:string)
//     // {
//     //   let s =document.createElement('button') as HTMLElement;
//     //   s.innerText=add;
//     // //console.log(s.innerHTML);
//     // let g = document.getElementById('ele') as HTMLElement;
//     // g.appendChild(s);

//     // }

//   // x:number=0;
//   // y:number=1;
//   // fib:any ='';
//   // i:any='';
//   // n:any='';
//   // display:any ='';

//   // fibonacci ()
//   // {
//   //   this.x=0;
//   //   this.y=1;
//   //   for(this.i=1;this.i<=this.n;this.i++)
//   //   {

//   //       console.log(this.x);

//   //       this.fib=Number(this.x)+Number(this.y);
//   //       this.x=this.y;
//   //       this.y=this.fib;

//   //   }
//   // }


//   // looping(){
//   //   let stars ='';
//   //   for(let i=1; i<this.n; i++){
//   //     for(let x=0; x<i; x++){
//   //       stars+='*';
//   //     }
//   //     this.changeColor(stars);
//   //     stars='';
//   //   }
//   // }

//   //create element x
//   //add content to x
//   // get refrence of parent (y)
//   // add x to parent y

//   // changeColor(text: string)
//   // {
//   //   let a=document.createElement('p') as HTMLElement;
//   //   a.innerText = text;
//   //   console.log(a.innerText);
//   //   let x = document.getElementById('container') as HTMLInputElement;
//   //   x.appendChild(a);
//   // }

//   // printing()
//   // {

//   //   let a=0;
//   //   let b=1;
//   //   let fib=0;
//   //   for(let i=1;i<this.n;i++)
//   //   {

//   //      this.printfib(this.fib);
//   //     this.fib=a+b;
//   //     a=b;
//   //     b=this.fib;



//   //   }
//   // }


//   // printfib(num:string)
//   // {
//   //   let x = document.createElement('p') as HTMLElement;
//   //   x.innerText=num;
//   //   console.log(x.innerText);
//   //   let y = document.getElementById('fibon') as HTMLElement;
//   //   y.appendChild(x);

//   // }

//   // print(number:string)
//   // {
//   //   let a =document.createElement('p') as HTMLElement;
//   //   a.innerText=number;
//   //   console.log(a.innerHTML);
//   //   let y =document.getElementById('fibon') as HTMLElement;
//   //   y.appendChild(a);
//   // }



//   print(number:string)
//   {
//     let s =document.createElement('button') as HTMLElement;
//     s.innerText=number;
//     //console.log(s.innerHTML);
//     let g = document.getElementById('fibon') as HTMLElement;
//     g.appendChild(s);
//   }

// x:number=0;
// y:number=1;
// fib:any=0;
// i:any='';
// n:any=''
// m:any=''
// stars=''
// calfib()
// {

//   for(this.x=0;this.i<=this.n;this.i++)
//   {
//     console.log(this.x);
//     this.print(this.fib);
//     this.fib=this.x+this.y;
//     this.x=this.y;
//     this.y=this.fib;
//   }
// }


// star()
// {
//   for(let i=1;i<=this.m;i++)
//   {
//     for(let j=0;j<i;j++)
//     {
//       this.stars+="*";
//     }
//     this.print(this.stars);
//     this.stars='';
//   }
// }


// printstar(text:string)
// {
//   let x = document.createElement('p') as HTMLElement;
//   x.innerText=text;
//   let y = document.getElementById('print') as HTMLElement;
//   y.appendChild(x);
// }


// emp1:Array<string>=[]
// n:any=''
// star='*'
// emp=''
// starprint()
// {
//   for(let i=1;i<=this.n;i++)
//   {
//     for(let j=0;j<i;j++)
//     {
//       this.star+="*";
//     }
//       this.star= ''
//       console.log(this.star)

//   }
// }

